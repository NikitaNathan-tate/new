﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaRental.Models
{
    public class CategoryModelsRepopsitory : ICategoryModelsRepository
    {
        private readonly IdentityContext _appDbContext;

        public CategoryModelsRepopsitory(IdentityContext appDbContext)
        {
            _appDbContext = appDbContext;
        }


        public IEnumerable<CategoryModels> AllCategories => _appDbContext.CategoryModels;
    }
}
