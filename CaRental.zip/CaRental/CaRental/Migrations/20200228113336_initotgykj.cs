﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CaRental.Migrations
{
    public partial class initotgykj : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CategoryModels",
                columns: table => new
                {
                    IdCategory = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CategoryModels", x => x.IdCategory);
                });

            migrationBuilder.CreateTable(
                name: "Person",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    UserName = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Person", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "Rental",
                columns: table => new
                {
                    IdRental = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false),
                    Priceperday = table.Column<string>(nullable: true),
                    UserId = table.Column<int>(nullable: false),
                    IdCar = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rental", x => x.IdRental);
                });

            migrationBuilder.CreateTable(
                name: "Car",
                columns: table => new
                {
                    IdCar = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(nullable: true),
                    Model = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Km = table.Column<int>(nullable: false),
                    CategoryModelsIdCategory = table.Column<int>(nullable: true),
                    IdCategory = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Car", x => x.IdCar);
                    table.ForeignKey(
                        name: "FK_Car_CategoryModels_CategoryModelsIdCategory",
                        column: x => x.CategoryModelsIdCategory,
                        principalTable: "CategoryModels",
                        principalColumn: "IdCategory",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Car",
                columns: new[] { "IdCar", "Brand", "CategoryModelsIdCategory", "Description", "IdCategory", "Km", "Model" },
                values: new object[,]
                {
                    { 1, "Audi", null, "hehehehehe", 1, 20, "Audi Q7" },
                    { 2, "Audi", null, "huhuhu", 1, 20, "Audi Q4" },
                    { 3, "Audi A3", null, "hahahaha", 2, 30, "Audi Q7" },
                    { 4, "Audi A4", null, "hihihi", 1, 30, "Audi Q7" }
                });

            migrationBuilder.InsertData(
                table: "CategoryModels",
                columns: new[] { "IdCategory", "CategoryName" },
                values: new object[,]
                {
                    { 1, "Sedan" },
                    { 2, "Hatchback" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Car_CategoryModelsIdCategory",
                table: "Car",
                column: "CategoryModelsIdCategory");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Car");

            migrationBuilder.DropTable(
                name: "Person");

            migrationBuilder.DropTable(
                name: "Rental");

            migrationBuilder.DropTable(
                name: "CategoryModels");
        }
    }
}
