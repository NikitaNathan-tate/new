﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CaRental.Models;

namespace CaRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryModelsController : ControllerBase
    {
        private readonly IdentityContext _context;
        private readonly ICategoryModelsRepository _categoryModelsRepository;

        public CategoryModelsController(IdentityContext context, ICategoryModelsRepository categoryModelsRepository)
        {
            _context = context;
            _categoryModelsRepository = categoryModelsRepository;
        }

        // GET: api/CategoryModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoryModels>>> GetCategoryModels()
        {
            return _categoryModelsRepository.AllCategories.ToList();
        }

        // GET: api/CategoryModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoryModels>> GetCategoryModels(int id)
        {
            var categoryModels = await _context.CategoryModels.FindAsync(id);

            categoryModels.Car = _context.Car.Where(c => c.IdCategory == id).ToList();

            if (categoryModels == null)
            {
                return NotFound();
            }

            return categoryModels;
        }

        // PUT: api/CategoryModels/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategoryModels(int id, CategoryModels categoryModels)
        {
            if (id != categoryModels.IdCategory)
            {
                return BadRequest();
            }

            _context.Entry(categoryModels).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoryModelsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CategoryModels
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<CategoryModels>> PostCategoryModels(CategoryModels categoryModels)
        {
            _context.CategoryModels.Add(categoryModels);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCategoryModels", new { id = categoryModels.IdCategory }, categoryModels);
        }

        // DELETE: api/CategoryModels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CategoryModels>> DeleteCategoryModels(int id)
        {
            var categoryModels = await _context.CategoryModels.FindAsync(id);
            if (categoryModels == null)
            {
                return NotFound();
            }

            _context.CategoryModels.Remove(categoryModels);
            await _context.SaveChangesAsync();

            return categoryModels;
        }

        private bool CategoryModelsExists(int id)
        {
            return _context.CategoryModels.Any(e => e.IdCategory == id);
        }
    }
}
